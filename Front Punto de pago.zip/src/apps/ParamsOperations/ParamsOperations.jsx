import HNavbar from "../../components/Base/HNavbar";

const ParamsOperations = ({ subRoutes }) => {
  return <HNavbar links={subRoutes} isIcon />;
};

export default ParamsOperations;
