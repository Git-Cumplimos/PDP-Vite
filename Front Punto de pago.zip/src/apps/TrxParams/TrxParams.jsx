import HNavbar from "../../components/Base/HNavbar";

const TrxParams = ({ subRoutes }) => {
  return <HNavbar links={subRoutes} isIcon />;
};

export default TrxParams;
