export { default } from "./ProvideImgs";
