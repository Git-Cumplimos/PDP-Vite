export { default } from "./RightArrow";
