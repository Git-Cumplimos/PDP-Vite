import HNavbar from "../../components/Base/HNavbar";

const FunMujer = ({ subRoutes }) => {
  return <HNavbar links={subRoutes} isIcon />;
};

export default FunMujer;
