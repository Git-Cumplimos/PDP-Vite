import HNavbar from "../../components/Base/HNavbar";

const LoteriaBog = ({ subRoutes }) => {
  return <HNavbar links={subRoutes} isIcon />;
};

export default LoteriaBog;
