import HNavbar from "../../../components/Base/HNavbar";

const Comisiones = ({ subRoutes }) => {
  return <HNavbar links={subRoutes} isIcon />;
};

export default Comisiones;
