export const enumParametrosAutorizador = Object.freeze({
  limite_superior_cash_out_movii: 1,
  limite_inferior_cash_out_movii: 2,
});
