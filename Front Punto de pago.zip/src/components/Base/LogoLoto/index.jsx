export { default } from "./LogoLoto";
