export { default } from "./SimpleLoading";
