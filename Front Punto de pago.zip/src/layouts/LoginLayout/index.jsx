export { default } from "./LoginLayout";
