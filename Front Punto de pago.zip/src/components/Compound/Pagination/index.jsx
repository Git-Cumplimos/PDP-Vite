export { default } from "./Pagination";
