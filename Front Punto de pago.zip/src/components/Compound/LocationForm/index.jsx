export { default } from "./LocationForm";
