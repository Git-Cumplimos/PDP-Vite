export { default } from "./MicroTable";
