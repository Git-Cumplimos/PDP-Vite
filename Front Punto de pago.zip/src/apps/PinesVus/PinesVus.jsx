import HNavbar from "../../components/Base/HNavbar";

const PinesVus = ({ subRoutes }) => {
  return <HNavbar links={subRoutes} isIcon />;
};

export default PinesVus;
