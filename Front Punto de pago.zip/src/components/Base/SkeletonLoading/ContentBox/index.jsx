export { default } from "./ContentBox";
