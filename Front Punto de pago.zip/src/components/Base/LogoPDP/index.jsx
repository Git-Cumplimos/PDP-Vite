export { default } from "./LogoPDP";
