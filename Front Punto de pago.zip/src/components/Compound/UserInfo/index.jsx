export { default } from "./UserInfo";
