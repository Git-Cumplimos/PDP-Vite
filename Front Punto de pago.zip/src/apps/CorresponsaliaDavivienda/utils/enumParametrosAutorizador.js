export const enumParametrosAutorizador = Object.freeze({
  limite_superior_cash_out_movii: 1,
  limite_inferior_cash_out_movii: 2,
  limite_superior_cash_out_davivienda_cb: 3,
  limite_inferior_cash_out_davivienda_cb: 4,
  limite_superior_pago_productos_propios_davivienda_cb: 5,
  limite_inferior_pago_productos_propios_davivienda_cb: 6,
});
