export { default } from "./Select";
