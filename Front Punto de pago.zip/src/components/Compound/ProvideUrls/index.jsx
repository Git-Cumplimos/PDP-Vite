export { default } from "./ProvideUrls";
