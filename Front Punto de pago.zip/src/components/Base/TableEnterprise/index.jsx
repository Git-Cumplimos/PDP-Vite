export { default } from "./TableEnterprise";
